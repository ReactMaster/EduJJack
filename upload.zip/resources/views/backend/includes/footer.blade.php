<footer class="app-footer">
    <strong>{{ __('labels.general.copyright') }} &copy; {{ date('Y') }} 
        <a href="/">{{config('site_settings.site_name')}}</a>
    </strong> {{ __('strings.backend.general.all_rights_reserved') }}

    <span class="float-right">Powered by <a href="https://supportcube.io" target="_blank">EduCore</a></span>
</footer>