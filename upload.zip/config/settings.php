<?php

return [
    'enable_demo' => false,
    
    'adsense_ad_client' => 'ca-pub-1722028856965661',
    'adsense_sidebar_responsive_slot' => '5558331441',
    'adsense_top_responsive_slot' => '5410991781',
    
    // cookie lifetime in minutes
    'affiliate_cookie_lifetime' => '1440',
    'payout_weeks' => 2,
    
    'enable_affiliate' => false,
    

];