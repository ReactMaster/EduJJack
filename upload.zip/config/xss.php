<?php

 /**
  * Here you can define all the routes that will be not be checked by XSS Protection middleware
  */

return array(
        'api/author/course' => array('description'),
    );
?>