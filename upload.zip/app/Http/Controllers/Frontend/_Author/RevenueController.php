<?php

namespace App\Http\Controllers\Frontend\_Author;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RevenueController extends Controller
{
    //
}
